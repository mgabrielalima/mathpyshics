let clickedPosition;
let vector1, vector2, vector3;

class V2 {
  constructor(position1, position2) {
    this.initialPosition = [...position1];
    this.finalPosition = [...position2];
  }

  read() {
    return (
      "(" +
      coordinatesText(this.initialPosition) +
      ", " +
      coordinatesText(this.finalPosition) +
      ")"
    );
  }

  length() {
    return sqrt(
      (this.finalPosition[0] - this.initialPosition[0]) ** 2 +
        (this.finalPosition[1] - this.initialPosition[1]) ** 2
    );
  }

  sum(summedVector) {
    return new V2(this.initialPosition, summedVector.finalPosition);
  }

  subtract(subtractedVector) {
    return this.sum(subtractedVector.invert());
  }

  invert() {
    return new V2(this.initialPosition, [
      2 * this.initialPosition[0] - this.finalPosition[0],
      2 * this.initialPosition[1] - this.finalPosition[1],
    ]);
  }

  mult(value) {
    return new V2(
      [...this.initialPosition],
      this.finalPosition.map(
        (p, i) =>
          (p - this.initialPosition[i]) * value + this.initialPosition[i]
      )
    );
  }

  dotProduct(multipliedVector) {
    const v1 = this.moveToPosition([0, 0]).finalPosition;
    const v2 = multipliedVector.moveToPosition([0, 0]).finalPosition;
    return v1[0] * v2[0] + v1[1] * v2[1];
  }

  crossProduct(multipliedVector) {
    const v1 = this.moveToPosition([0, 0]).finalPosition;
    const v2 = multipliedVector.moveToPosition([0, 0]).finalPosition;

    return [0, 0, v1[0] * v2[1] - v1[1] * v2[0]];
  }

  project(baseVector) {
    const multiplier =
      this.dotProduct(baseVector) / baseVector.dotProduct(baseVector);
    return baseVector.mult(multiplier);
  }

  normalUnitVector() {
    const tanVertical =
      (this.finalPosition[0] - this.initialPosition[0]) /
      (this.finalPosition[1] - this.initialPosition[1]);
    
    const finalPosition = [
      this.initialPosition[0] + sqrt(1 / (1 + tanVertical ** 2)),
      this.initialPosition[1] - tanVertical * sqrt(1 / (1 + tanVertical ** 2)),
    ];

    return new V2(this.initialPosition, finalPosition);
  }

  moveToPosition(newInitialPosition) {
    return new V2(
      newInitialPosition,
      [
        this.finalPosition[0] - this.initialPosition[0] + newInitialPosition[0],
        this.finalPosition[1] - this.initialPosition[1] + newInitialPosition[1],
      ]
    );
  }

  drawVector() {
    line(...this.initialPosition, ...this.finalPosition);

    const dx = this.finalPosition[0] - this.initialPosition[0];
    const dy = this.finalPosition[1] - this.initialPosition[1];
    const le = sqrt(dx * dx + dy * dy);
    const vx = dx / le;
    const vy = dy / le;
    const ux = -vy;
    const uy = vx;

    triangle(
      ...this.finalPosition,
      this.finalPosition[0] - 10 * vx + 6 * ux,
      this.finalPosition[1] - 10 * vy + 6 * uy,
      this.finalPosition[0] - 10 * vx - 6 * ux,
      this.finalPosition[1] - 10 * vy - 6 * uy
    );
  }
}

function drawAxis() {
  fill(0);
  stroke(0);

  const arrowWidth = 9;
  const arrowHeight = 3;

  //x Axis
  line(-width / 2, 0, width / 2, 0);
  line(width / 2 - arrowWidth, -arrowHeight, width / 2, 0);
  line(width / 2 - arrowWidth, arrowHeight, width / 2, 0);

  //y Axis
  line(0, -height / 2, 0, height / 2);
  line(0, -height / 2, -arrowHeight, -height / 2 + arrowWidth);
  line(0, -height / 2, arrowHeight, -height / 2 + arrowWidth);
}

function getAdjustedMouse() {
  return [mouseX - width / 2, mouseY - height / 2];
}

function coordinatesText(coordinates) {
  if (coordinates[2]) {
    return (
      "(" +
      coordinates[0] +
      ", " +
      -coordinates[1] +
      ", " +
      coordinates[2] +
      ")"
    );
  }
  return "(" + coordinates[0] + ", " + -coordinates[1] + ")";
}

function mouseClicked() {
  if (!vector1) {
    if (!clickedPosition) {
      clickedPosition = getAdjustedMouse();
      console.log(coordinatesText(getAdjustedMouse()));
      console.log("Clique novamente para definir o final de seu vetor");
    } else {
      vector1 = new V2(clickedPosition, getAdjustedMouse());
      clickedPosition = getAdjustedMouse();
      console.log(coordinatesText(getAdjustedMouse()));
      console.log("Clique novamente para definir seu segundo vetor");
    }
  } else if (!vector2) {
    vector2 = new V2(clickedPosition, getAdjustedMouse());
    console.log(coordinatesText(getAdjustedMouse()));
    clickedPosition = null;

    console.log("A - somar vetores");
    console.log("S - subtrair vetores");
    console.log("D - inverter primeiro vetor");
    console.log("F - multiplicar primeiro vetor por valor aleatório");
    console.log("G - produto escalar dos vetores");
    console.log("H - produto vetorial dos vetores");
    console.log("J - projeção do primeiro vetor sobre o segundo");
    console.log("K - deslizamento do primeiro vetor sobre o segundo");
    console.log("L - reflexão do primeiro vetor sobre o segundo");
  }
}

function keyPressed() {
  if (vector1 && vector2) {
    if (keyCode === 65) {
      vector3 = vector1.sum(vector2);
    }
    if (keyCode === 83) {
      vector3 = vector1.subtract(vector2);
    }
    if (keyCode === 68) {
      vector3 = vector1.invert();
    }
    if (keyCode === 70) {
      const multiplier = round(random() * 3, 2);
      console.log(multiplier);
      vector3 = vector1.mult(multiplier);
    }
    if (keyCode === 71) {
      console.log(
        "O produto escalar de " +
          vector1.read() +
          " com " +
          vector2.read() +
          " resulta em " +
          vector1.dotProduct(vector2)
      );
    }
    if (keyCode === 72) {
      console.log(
        "O produto vetorial de " +
          vector1.read() +
          " com " +
          vector2.read() +
          " resulta em " +
          coordinatesText(vector1.crossProduct(vector2))
      );
    }
    if (keyCode == 74) {
      vector3 = vector1.project(vector2);
    }
    if (keyCode == 75) {
      const normalUnitVector = vector2.normalUnitVector();
      const normalVector = normalUnitVector.mult(normalUnitVector.dotProduct(vector1));
      vector3 = vector1.subtract(normalVector);
    }
    if (keyCode == 76) {
      const normalUnitVector = vector2.normalUnitVector();
      const doubleNormalVector = normalUnitVector.mult(2*normalUnitVector.dotProduct(vector1));
      let reflectedVector = vector1.subtract(doubleNormalVector);
      vector3 = reflectedVector.moveToPosition(vector2.initialPosition);
    }
  }
}

function setup() {
  createCanvas(400, 400);

  console.log(
    "Clique em algum local da tela para começar a desenhar o seu vetor"
  );
}

function draw() {
  translate(width / 2, height / 2);
  background(245);

  drawAxis();

  fill(0, 128, 0);
  stroke(0, 128, 0);

  if (vector1) {
    vector1.drawVector();
  } else if (clickedPosition) {
    line(...clickedPosition, ...getAdjustedMouse());
  }

  fill(128, 0, 0);
  stroke(128, 0, 0);

  if (vector1 && clickedPosition) {
    line(...clickedPosition, ...getAdjustedMouse());
  } else if (vector2) {
    vector2.drawVector();
  }

  fill(0, 0, 128);
  stroke(0, 0, 128);

  if (vector3) {
    vector3.drawVector();
  }
}
